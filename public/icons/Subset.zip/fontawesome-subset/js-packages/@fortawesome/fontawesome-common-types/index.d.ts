export type IconPrefix = "fas" | "fab" | "far" | "fal" | "fad";
export type IconPathData = string | string[]

export interface IconLookup {
  prefix: IconPrefix;
  // IconName is defined in the code that will be generated at build time and bundled with this file.
  iconName: IconName;
}

export interface IconDefinition extends IconLookup {
  icon: [
    number, // width
    number, // height
    string[], // ligatures
    string, // unicode
    IconPathData // svgPathData
  ];
}

export interface IconPack {
  [key: string]: IconDefinition;
}

export type IconName = 'arrow-right' | 
  'bars' | 
  'bed' | 
  'bolt' | 
  'book' | 
  'calendar' | 
  'check' | 
  'check-circle' | 
  'chevron-down' | 
  'chevron-right' | 
  'circle' | 
  'circle-notch' | 
  'clock' | 
  'cloud-upload' | 
  'cogs' | 
  'comment-alt' | 
  'ellipsis-h' | 
  'envelope' | 
  'exclamation-triangle' | 
  'file-pdf' | 
  'home' | 
  'link' | 
  'lock-alt' | 
  'male' | 
  'map-marker' | 
  'minus' | 
  'minus-circle' | 
  'plus' | 
  'plus-circle' | 
  'question-circle' | 
  'search' | 
  'sign-in' | 
  'sink' | 
  'tachometer-alt-fast' | 
  'times' | 
  'times-square' | 
  'user' | 
  'user-headset';
